import argparse
from itertools import groupby
from difflib import SequenceMatcher

parser = argparse.ArgumentParser(description='This script checks accuracy of your parsing')
parser.add_argument('standard', type=str, help='Path to the golden standard')
parser.add_argument('yourtext', type=str, help='Path to your tokens')
parser.add_argument('--all', dest="all", help='Show more than default five', action='store_true')
args = parser.parse_args()

with open(args.standard) as f:
    standard = f.readlines()

with open(args.yourtext) as g:
    yourtext = g.readlines()

standard = ["".join(group).replace("\n", "|") for k, group in groupby(standard, lambda x: x == '\n') if not k]
yourtext = ["".join(group).replace("\n", "|") for k, group in groupby(yourtext, lambda x: x == '\n') if not k]

if len(standard) != len(yourtext):
    raise ValueError("The amount of texts in the original and the amount of texts in your file are not equal\n"
                     "Be sure to divide texts by an empty line\n"
                     "In the original file every line is considered a separate text\n")
accuracies = []
error_number = 0
for st, ur in zip(standard, yourtext):
    s = SequenceMatcher(None, st, ur)
    correct = 0
    incorrect = 0
    first = True
    len_st = len(st)
    len_ur = len(ur)
    for tag, i1, i2, j1, j2 in s.get_opcodes():
        if tag != "equal":
            if (not args.all and error_number < 5) or args.all:
                if first:
                    print("Found error(s) in text: {}".format(st[:30]))
                    first = False
                tagging = "Invalid splitting" if tag == "insert" else "Invalid lumping"
                print('{}\n'
                      'original: "{}"\n'
                      '    your: "{}"\n'.format(tagging, st[max(0, i1-15):min(i2+15, len_st-1)], ur[max(0, j1-15):min(i2+15, len_ur-1)]))
                error_number += 1
            incorrect += 1
        else:
            correct += 1
    try:
        accuracy = correct/(correct + incorrect)
    except ZeroDivisionError:
        accuracy = 0        
    accuracies.append(accuracy)

print("Average accuracy: {:.1%}".format(sum(accuracies)/len(accuracies)))
